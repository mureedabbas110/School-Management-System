# SchoolManagementSystem
 This is basic School Management Application using Java Swing, Java OOP concept, MySQL, JDBC  and that is create & maintained by Mureed Abbas Qazi, Bilawal Gul Memon and Abdul Ahad Mahar
