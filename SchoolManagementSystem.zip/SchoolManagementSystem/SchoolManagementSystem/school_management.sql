CREATE DATABASE school_management;
USE school_management;


select * from students;



CREATE TABLE teachers (
                          id INT AUTO_INCREMENT PRIMARY KEY,
                          username VARCHAR(50) NOT NULL,
                          password VARCHAR(50) NOT NULL
)Auto_INCREMENT = 101;
INSERT INTO teachers (username, password) VALUES ('rashid', '1234');
INSERT INTO teachers (username, password) VALUES ('zaid', '1234');
INSERT INTO teachers (username, password) VALUES ('umair', '1234');
INSERT INTO teachers (username, password) VALUES ('shoaib', '1234');
INSERT INTO teachers (username, password) VALUES ('javad', '1234');
select * from teachers;

CREATE TABLE students (
                          student_id INT AUTO_INCREMENT PRIMARY KEY,
                          first_name VARCHAR(100) NOT NULL,
                          last_name VARCHAR(100) NOT NULL,
                          date_of_birth DATE NOT NULL,
                          gender VARCHAR(10) NOT NULL,
                          class varchar(15) NOT NULL
);

create table teacher_info(
                             teacher_id int Auto_INCREMENT PRIMARY KEY,
                             first_name VARCHAR(100) NOT NULL,
                             last_name VARCHAR(100) NOT NULL,
                             date_of_birth DATE NOT NULL,
                             gender VARCHAR(10) NOT NULL,
                             class varchar(15) NOT NULL
                           )Auto_INCREMENT = 1000;

INSERT INTO teacher_info (first_name ,
                          last_name ,
                          date_of_birth ,
                          gender ,
                          class
) VALUES ('rashid', 'ahmed','2000-03-07','Male','six');


INSERT INTO teacher_info (first_name ,
                          last_name ,
                          date_of_birth ,
                          gender ,
                          class
) VALUES ('shoaib', 'ahmed','2004-03-17','Male','seven');


INSERT INTO teacher_info (first_name ,
                          last_name ,
                          date_of_birth ,
                          gender ,
                          class
) VALUES ('jawad', 'ali','2003-11-21','Male','eight');


INSERT INTO teacher_info (first_name ,
                          last_name ,
                          date_of_birth ,
                          gender ,
                          class
) VALUES ('Zaid','memon','2005-02-06','Male','nine');



INSERT INTO teacher_info (first_name ,
                          last_name ,
                          date_of_birth ,
                          gender ,
                          class
) VALUES ('umair', 'ahmed','2004-11-23','Male','ten');


select * from students;



use school_management;
INSERT INTO students (first_name ,
                      last_name ,
                      date_of_birth ,
                      gender ,
                      class
) VALUES ('ali', 'ahmed','2000-03-07','Male','six');


INSERT INTO students (first_name ,
                      last_name ,
                      date_of_birth ,
                      gender ,
                      class
) VALUES ('asad', 'ahmed','2004-03-17','Male','seven');


INSERT INTO students (first_name ,
                      last_name ,
                      date_of_birth ,
                      gender ,
                      class
) VALUES ('asif', 'ali','2003-11-21','Male','eight');


INSERT INTO students (first_name ,
                      last_name ,
                      date_of_birth ,
                      gender ,
                      class
) VALUES ('arif','memon','2005-02-06','Male','nine');



INSERT INTO students (first_name ,
                      last_name ,
                      date_of_birth ,
                      gender ,
                      class
) VALUES ('asadullah', 'ahmed','2004-11-23','Male','ten');


