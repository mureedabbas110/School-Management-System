# School-Management-System-Java

A Java Swing + JDBC-based School Management System with Admin and Student portals.

## 🧾 Features

- 🔐 Admin and Student Login System
- 🏫 Student Management: Add, Update, Delete Students
- 📚 Course Management (Optional)
- 📊 View and Update Marks/Grades
- 🗂️ Simple GUI built using Java Swing
- 💾 Backend powered by MySQL using JDBC

## 🛠️ Technologies Used

- Java (JDK 24+)
- Java Swing (GUI)
- JDBC (Database Connectivity)
- MySQL

## 💻 Screenshots

<!-- Add screenshots here (you can paste images in Markdown if using GitHub) -->
*Login Page*  
![Login Screenshot](./public/login.png)

*Admin Dashboard*  
![Admin Screenshot](./public/admin.png)

## 🚀 Getting Started

### Prerequisites

- Java JDK installed
- MySQL server running
- MySQL Workbench or any GUI tool (optional)
- Git (to clone this repo)

### 📦 Setup Instructions

1. **Clone the repository:**
   ```bash
   git clone https://github.com/AAhadM/SchoolManagementSystem.git
   cd School-Management-System
