import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
public class RoleSelectionPage extends JFrame {
    public RoleSelectionPage() {
        setTitle("MBA GROUP School Management System");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setIconImage(new ImageIcon(getClass().getResource("logo.png")).getImage());
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(240, 240, 240));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        titlePanel.setBackground(new Color(240, 240, 240));

        JLabel logoLabel = new JLabel(new ImageIcon("./logo.jpg"));
        JLabel titleLabel = new JLabel("Welcome to MBA GROUP SMS");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titlePanel.add(logoLabel);
        titlePanel.add(titleLabel);
        mainPanel.add(titlePanel, BorderLayout.NORTH);

        ImageIcon image = new ImageIcon("download.jpg");


        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
        buttonPanel.setBackground(new Color(240, 240, 240));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));

        JLabel roleLabel = new JLabel("Select your role:");
        roleLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        roleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonPanel.add(roleLabel);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        roleLabel.setIcon(image);
        titleLabel.add(roleLabel);



        JButton adminButton = createCenteredButton("Administrator", new Color(70, 130, 180));
        JButton teacherButton = createCenteredButton("Teacher", new Color(95, 32, 32));
        JButton studentButton = createCenteredButton("Student Admission", new Color(60, 179, 113));
        JButton aboutButton = createCenteredButton("About System", new Color(169, 169, 169));
        JButton exitButton = createCenteredButton("Exit System", new Color(205, 92, 92));

        buttonPanel.add(adminButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        buttonPanel.add(teacherButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        buttonPanel.add(studentButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        buttonPanel.add(aboutButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        buttonPanel.add(exitButton);

        mainPanel.add(buttonPanel, BorderLayout.CENTER);
        add(mainPanel);

        adminButton.addActionListener(e -> {
            dispose();
            new AdminOption().setVisible(true);
        });

        teacherButton.addActionListener(e -> {
            dispose();
            new TeacherLogin().setVisible(true);
          });


        studentButton.addActionListener(e -> {
            dispose();
            new StudentAdmissionPage().setVisible(true);
        });

        aboutButton.addActionListener(e -> showAboutDialog());
        exitButton.addActionListener(e -> System.exit(0));
    }

    private JButton createCenteredButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setMaximumSize(new Dimension(250, 40));
        button.setPreferredSize(new Dimension(250, 40));
        button.setMinimumSize(new Dimension(250, 40));
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        return button;
    }

    private void showAboutDialog() {
        String aboutText = "<html><div style='text-align: center;'>"
                + "<h1>MBA GROUP School Management System</h1>"
                + "<p>Version 1.0</p>"
                + "<p>Developed by Mureed Abbas Qazi, Bilawal Gul Memon, and Abdul Ahad Mahar</p>"
                + "<p>© 2025 All Rights Reserved</p>"
                + "<hr>"
                + "<p>This software is designed to manage school administration tasks, "
                + "student admissions, and other educational processes.</p>"
                + "<p>For support contact: kazimureedabbas@gmail.com</p>"
                + "<p>For support contact: Bilawalgul78@gmail.com</p>"
                + "<p>For support contact: abdulahadmahar11@gmail.com</p>"
                + "</div></html>";

        JOptionPane.showMessageDialog(this,
                aboutText,
                "About MBA GROUP SMS",
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon("about_icon.jpg"));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            RoleSelectionPage roleSelectionPage = new RoleSelectionPage();
            roleSelectionPage.setVisible(true);
        });
    }
}