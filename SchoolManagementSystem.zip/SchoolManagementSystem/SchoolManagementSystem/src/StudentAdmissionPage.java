import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class StudentAdmissionPage extends JFrame {
    private JTextField firstNameField, lastNameField, dobField, genderField, classField;

    public StudentAdmissionPage() {
        setTitle("Student Admission");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setIconImage(new ImageIcon(getClass().getResource("logo.png")).getImage());
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(240, 240, 240));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;

        JLabel titleLabel = new JLabel("Student Admission Form");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(titleLabel, gbc);

        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        panel.add(firstNameLabel, gbc);

        firstNameField = new JTextField(20);
        gbc.gridx = 1;
        panel.add(firstNameField, gbc);

        JLabel lastNameLabel = new JLabel("Last Name:");
        lastNameLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(lastNameLabel, gbc);

        lastNameField = new JTextField(20);
        gbc.gridx = 1;
        panel.add(lastNameField, gbc);

        JLabel dobLabel = new JLabel("Date of Birth (YYYY-MM-DD):");
        dobLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(dobLabel, gbc);

        dobField = new JTextField(20);
        gbc.gridx = 1;
        panel.add(dobField, gbc);

        JLabel genderLabel = new JLabel("Gender:");
        genderLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(genderLabel, gbc);

        genderField = new JTextField(20);
        gbc.gridx = 1;
        panel.add(genderField, gbc);

        JLabel classIdLabel = new JLabel("Class:");
        classIdLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 5;
        panel.add(classIdLabel, gbc);

        classField = new JTextField(20);
        gbc.gridx = 1;
        panel.add(classField, gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));

        JButton submitButton = new JButton("Submit");
        styleButton(submitButton, new Color(60, 179, 113));

        JButton clearButton = new JButton("Clear");
        styleButton(clearButton, new Color(70, 130, 180));

        JButton backButton = new JButton("Back");
        styleButton(backButton, new Color(205, 92, 92));

        buttonPanel.add(submitButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(backButton);

        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.CENTER;
        panel.add(buttonPanel, gbc);

        add(panel);

        submitButton.addActionListener(e -> submitForm());

        clearButton.addActionListener(e -> {
            firstNameField.setText("");
            lastNameField.setText("");
            dobField.setText("");
            genderField.setText("");
            classField.setText("");
        });

        backButton.addActionListener(e -> {
            dispose();
            new RoleSelectionPage().setVisible(true);
        });
    }

    private void styleButton(JButton button, Color color) {
        button.setPreferredSize(new Dimension(100, 30));
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
    }
    private void submitForm() {

        if (firstNameField.getText().isEmpty() || lastNameField.getText().isEmpty() ||
                dobField.getText().isEmpty() || genderField.getText().isEmpty() ||
                classField.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        dateFormat.setLenient(false);

        try {
            dateFormat.parse(dobField.getText());
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(this, "Invalid date format. Please use YYYY-MM-DD", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }


        Student student = new Student();
        student.setFirstName(firstNameField.getText());
        student.setLastName(lastNameField.getText());
        student.setDateOfBirth(dobField.getText());
        student.setGender(genderField.getText());
        student.setClasses(classField.getText());

        if (saveStudent(student)) {
            JOptionPane.showMessageDialog(this, "Student admission successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
            clearForm();
        } else {
            JOptionPane.showMessageDialog(this, "Error saving student data", "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean saveStudent(Student student) {
        String query = "INSERT INTO students (first_name, last_name, date_of_birth, gender, class) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, student.getFirstName());
            stmt.setString(2, student.getLastName());
            stmt.setString(3, student.getDateOfBirth());
            stmt.setString(4, student.getGender());
            stmt.setString(5, student.getClasses());

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        student.setStudentId(generatedKeys.getInt(1));
                    }
                }
                return true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    private void clearForm() {
        firstNameField.setText("");
        lastNameField.setText("");
        dobField.setText("");
        genderField.setText("");
        classField.setText("");
    }
}