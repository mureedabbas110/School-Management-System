import javax.swing.*;
import java.awt.*;

import static java.awt.SystemColor.text;

public class AdminOption extends JFrame {
    public AdminOption() {
        setTitle("whan to do See");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setIconImage(new ImageIcon(getClass().getResource("logo.png")).getImage());

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(240, 240, 240));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        titlePanel.setBackground(new Color(240, 240, 240));

        JLabel logoLabel = new JLabel(new ImageIcon("./logo.jpg"));
        JLabel titleLabel = new JLabel("Details");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));

        titlePanel.add(logoLabel);
        titlePanel.add(titleLabel);
        mainPanel.add(titlePanel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
        buttonPanel.setBackground(new Color(240, 240, 240));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));

        JLabel roleLabel = new JLabel("Select your role:");
        roleLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        roleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonPanel.add(roleLabel);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 15)));

        JButton teacher_infoButton = createCenteredButton("Teacher_info", new Color(70, 130, 180));
        JButton student_infoButton = createCenteredButton("Student_info", new Color(95, 32, 32));

        buttonPanel.add(teacher_infoButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        buttonPanel.add(student_infoButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        mainPanel.add(buttonPanel, BorderLayout.CENTER);
        add(mainPanel);

        teacher_infoButton.addActionListener(e -> {
            dispose();

              new NewDashboard().setVisible(true);
        });

        student_infoButton.addActionListener(e -> {
            dispose();
            new AdminLoginPage().setVisible(true);

        });
    }
        private JButton createCenteredButton (String text, Color color){
            JButton button = new JButton(text);
            button.setAlignmentX(Component.CENTER_ALIGNMENT);
            button.setMaximumSize(new Dimension(250, 40));
            button.setPreferredSize(new Dimension(250, 40));
            button.setMinimumSize(new Dimension(250, 40));
            button.setFont(new Font("Arial", Font.BOLD, 14));
            button.setBackground(color);
            button.setForeground(Color.WHITE);
            button.setFocusPainted(false);
            return button;
        }

    }

