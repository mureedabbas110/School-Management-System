import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class TeacherDashboard extends JFrame {
    private JTable TeacherTable;
    private DefaultTableModel tableModel;
    private AdminDashboard parent;

    public TeacherDashboard() {
        setTitle("Teacher Dashboard");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setIconImage(new ImageIcon(getClass().getResource("logo.png")).getImage());
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel titleLabel = new JLabel("Teacher Management", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, BorderLayout.NORTH);

        String[] columns = {"ID", "First Name", "Last Name", "Date of Birth", "Gender", "Class"};
        tableModel = new DefaultTableModel(columns, 0);
        TeacherTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(TeacherTable);
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));


        JButton refreshButton = new JButton("Refresh");
        styleButton(refreshButton, new Color(70, 130, 180));

        JButton backButton = new JButton("Logout");
        styleButton(backButton, new Color(169, 169, 169));

        buttonPanel.add(refreshButton);
        buttonPanel.add(backButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        add(panel);

        refreshTeacherData();

        refreshButton.addActionListener(e -> refreshTeacherData());


        backButton.addActionListener(e -> {
            dispose();
            new RoleSelectionPage().setVisible(true);
        });
    }

    private void styleButton(JButton button, Color color) {
        button.setPreferredSize(new Dimension(100, 30));
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
    }

    private void refreshTeacherData() {
        tableModel.setRowCount(0);

        String query = "SELECT * FROM Teacher_info";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Object[] row = {
                        rs.getInt("TEACHER_id"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getDate("date_of_birth"),
                        rs.getString("gender"),
                        rs.getString("class")
                };
                tableModel.addRow(row);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading TEACHER data", "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteTeacher(int teacherId) {
        String query = "DELETE FROM teacherInfo WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, teacherId);
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "teacher deleted successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error deleting teacher", "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void addStudentToTable(TeacherInfo teacherInfo) {
        Object[] row = {
                teacherInfo.getId(),
                teacherInfo.getFirstName(),
                teacherInfo.getLastName(),
                teacherInfo.getDateOfBirth(),
                teacherInfo.getGender(),
                teacherInfo.getClasses()
        };
        tableModel.addRow(row);
    }
}